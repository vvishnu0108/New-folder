import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const client = axios.create({
    baseURL: API,
    timeout: 240000,
    headers: { "Content-Type": "application/json" },
});

export const architectureApi = {
    extractIntent: (prompt, intake) =>
        client.post("/architecture/intent", { prompt, intake }).then((r) => r.data),

    clarify: (payload) =>
        client.post("/architecture/clarify", payload).then((r) => r.data),

    generate: (payload) =>
        client.post("/architecture/generate", payload).then((r) => r.data),

    refine: (payload) =>
        client.post("/architecture/refine", payload).then((r) => r.data),

    getSession: (sessionId) =>
        client.get(`/architecture/${sessionId}`).then((r) => r.data),

    listSessions: () =>
        client.get("/architecture/sessions").then((r) => r.data),

    listTemplates: () =>
        client.get("/architecture/templates").then((r) => r.data),

    // Snapshots
    createSnapshot: (sessionId, body) =>
        client.post(`/architecture/${sessionId}/snapshots`, body).then((r) => r.data),
    listSnapshots: (sessionId) =>
        client.get(`/architecture/${sessionId}/snapshots`).then((r) => r.data),
    restoreSnapshot: (sessionId, snapshotId) =>
        client.post(`/architecture/${sessionId}/snapshots/${snapshotId}/restore`).then((r) => r.data),
};

/**
 * Stream architecture generation events.
 * onEvent({ stage, message?, payload? }) — payload is sent on stage="complete".
 * Returns an AbortController so the caller can cancel the stream.
 */
export function streamGenerate(payload, onEvent) {
    const controller = new AbortController();
    (async () => {
        try {
            const res = await fetch(`${API}/architecture/generate/stream`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Accept: "text/event-stream" },
                body: JSON.stringify(payload),
                signal: controller.signal,
            });
            if (!res.body) {
                onEvent({ stage: "error", message: "No SSE body" });
                return;
            }
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buffer = "";
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                let idx;
                while ((idx = buffer.indexOf("\n\n")) !== -1) {
                    const rawEvent = buffer.slice(0, idx);
                    buffer = buffer.slice(idx + 2);
                    const lines = rawEvent.split("\n");
                    let stage = "status";
                    let dataLines = [];
                    for (const ln of lines) {
                        if (ln.startsWith("event:")) stage = ln.slice(6).trim();
                        else if (ln.startsWith("data:")) dataLines.push(ln.slice(5).trim());
                    }
                    const dataStr = dataLines.join("\n");
                    if (!dataStr) continue;
                    try {
                        const parsed = JSON.parse(dataStr);
                        onEvent({ stage, ...parsed });
                    } catch {
                        onEvent({ stage, message: dataStr });
                    }
                }
            }
        } catch (e) {
            if (e.name !== "AbortError") {
                onEvent({ stage: "error", message: e.message });
            }
        }
    })();
    return controller;
}

export const mcpApi = {
    listSources: () => client.get("/mcp/sources").then((r) => r.data),
};

export default { architectureApi, mcpApi };
