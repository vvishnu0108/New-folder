import { create } from "zustand";

const emptyIntake = {
    cloud_provider: null,
    architecture_type: null,
    kubernetes: null,
    traffic_scale: null,
    high_availability: null,
    disaster_recovery: null,
    internet_facing: null,
    compliance: [],
    data_layer: null,
    authentication: null,
    messaging: null,
    monitoring: null,
    budget_sensitivity: null,
    workload_type: null,
    region_strategy: null,
    deployment_model: null,
};

const useArchitectureStore = create((set, get) => ({
    // Identity
    sessionId: null,

    // Intake + prompt
    prompt: "",
    intake: { ...emptyIntake },

    // Workflow state
    stage: "intake", // intake | clarification | reasoning | workspace
    loading: false,
    progressMessage: "",

    // Clarification
    clarificationQuestions: [],
    clarificationAnswers: {},

    // Result
    drawioXml: null,
    metadata: null,
    reasoning: [],
    validation: [],
    tradeoffs: [],
    recommendations: [],
    mcpSources: [],
    architectureScore: 0,
    conversation: [],

    // MCP probe data
    mcpSourcesStatus: [],

    // Templates
    templates: [],

    // Actions
    setPrompt: (prompt) => set({ prompt }),
    setIntakeField: (field, value) =>
        set((state) => ({ intake: { ...state.intake, [field]: value } })),
    setIntake: (intake) => set({ intake: { ...emptyIntake, ...intake } }),

    setStage: (stage) => set({ stage }),
    setLoading: (loading, message = "") => set({ loading, progressMessage: message }),

    setClarification: (questions) =>
        set({ clarificationQuestions: questions, clarificationAnswers: {} }),
    setClarificationAnswer: (qid, value) =>
        set((state) => ({
            clarificationAnswers: { ...state.clarificationAnswers, [qid]: value },
        })),

    applyGeneration: (result) =>
        set({
            sessionId: result.session_id,
            drawioXml: result.drawio_xml || null,
            metadata: result.metadata || null,
            reasoning: result.reasoning || [],
            validation: result.validation || [],
            tradeoffs: result.tradeoffs || [],
            recommendations: result.recommendations || [],
            mcpSources: result.mcp_sources || [],
            architectureScore: result.architecture_score || 0,
            stage: "workspace",
        }),

    updateDrawioXml: (xml) => set({ drawioXml: xml }),
    addConversation: (role, content) =>
        set((state) => ({
            conversation: [
                ...state.conversation,
                { role, content, timestamp: new Date().toISOString() },
            ],
        })),

    setMcpStatus: (sources) => set({ mcpSourcesStatus: sources }),
    setTemplates: (templates) => set({ templates }),

    reset: () =>
        set({
            sessionId: null,
            prompt: "",
            intake: { ...emptyIntake },
            stage: "intake",
            loading: false,
            progressMessage: "",
            clarificationQuestions: [],
            clarificationAnswers: {},
            drawioXml: null,
            metadata: null,
            reasoning: [],
            validation: [],
            tradeoffs: [],
            recommendations: [],
            mcpSources: [],
            architectureScore: 0,
            conversation: [],
        }),
}));

export default useArchitectureStore;
