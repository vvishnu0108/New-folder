import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "sonner";
import "@/App.css";
import "./styles/lenovo-overrides.css";
import { ThemeProvider, useTheme } from "./contexts/ThemeContext";
import Workspace from "./pages/Workspace";

function ToasterWithTheme() {
    const { theme } = useTheme();
    return (
        <Toaster
            position="bottom-right"
            theme={theme}
            toastOptions={{
                style: {
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    color: "hsl(var(--foreground))",
                },
            }}
        />
    );
}

function App() {
    return (
        <ThemeProvider>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Workspace />} />
                </Routes>
            </BrowserRouter>
            <ToasterWithTheme />
        </ThemeProvider>
    );
}

export default App;
