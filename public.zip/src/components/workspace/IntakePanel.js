import { useState } from "react";
import {
    Send, ChevronDown, ChevronRight, Sparkles, Cloud, Shield, Database,
    Globe2, Server, MessageSquare, GitBranch,
} from "lucide-react";
import { toast } from "sonner";
import useArchitectureStore from "../../store/useArchitectureStore";
import { architectureApi, streamGenerate } from "../../services/api";

const SELECT_FIELDS = [
    { key: "cloud_provider", label: "Cloud Provider", icon: Cloud, options: ["azure", "aws", "gcp", "multi"] },
    { key: "architecture_type", label: "Architecture Type", icon: GitBranch, options: ["microservices", "serverless", "event-driven", "monolith", "data-platform", "ml-platform"] },
    { key: "traffic_scale", label: "Traffic Scale", icon: Globe2, options: ["low", "medium", "high", "enterprise"] },
    { key: "workload_type", label: "Workload", icon: Server, options: ["web", "api", "batch", "stream", "ml", "iot"] },
    { key: "data_layer", label: "Data Layer", icon: Database, options: ["sql", "nosql", "hybrid", "data-warehouse", "streaming"] },
    { key: "region_strategy", label: "Region Strategy", icon: Globe2, options: ["single", "multi-region", "global"] },
    { key: "deployment_model", label: "Deployment", icon: Cloud, options: ["public", "hybrid", "private"] },
    { key: "authentication", label: "Authentication", icon: Shield, options: ["oauth", "saml", "jwt", "managed-identity"] },
    { key: "messaging", label: "Messaging", icon: MessageSquare, options: ["queue", "pubsub", "event-stream", "none"] },
    { key: "budget_sensitivity", label: "Budget", icon: Sparkles, options: ["low", "medium", "high"] },
];

const TOGGLE_FIELDS = [
    { key: "kubernetes", label: "Kubernetes" },
    { key: "high_availability", label: "High Availability" },
    { key: "disaster_recovery", label: "Disaster Recovery" },
    { key: "internet_facing", label: "Internet Facing" },
    { key: "monitoring", label: "Monitoring" },
];

const COMPLIANCE = ["HIPAA", "PCI", "SOC2", "GDPR", "FedRAMP", "ISO27001"];

export default function IntakePanel() {
    const prompt = useArchitectureStore((s) => s.prompt);
    const setPrompt = useArchitectureStore((s) => s.setPrompt);
    const intake = useArchitectureStore((s) => s.intake);
    const setIntakeField = useArchitectureStore((s) => s.setIntakeField);
    const setIntake = useArchitectureStore((s) => s.setIntake);
    const setStage = useArchitectureStore((s) => s.setStage);
    const setLoading = useArchitectureStore((s) => s.setLoading);
    const setClarification = useArchitectureStore((s) => s.setClarification);
    const applyGeneration = useArchitectureStore((s) => s.applyGeneration);
    const loading = useArchitectureStore((s) => s.loading);
    const progressMessage = useArchitectureStore((s) => s.progressMessage);

    const [advancedOpen, setAdvancedOpen] = useState(false);

    const toggleCompliance = (c) => {
        const cur = intake.compliance || [];
        setIntakeField("compliance", cur.includes(c) ? cur.filter((x) => x !== c) : [...cur, c]);
    };

    const handleAutoDetect = async () => {
        if (!prompt.trim()) {
            toast.error("Enter an architecture goal first");
            return;
        }
        setLoading(true, "Detecting intent…");
        try {
            const res = await architectureApi.extractIntent(prompt, intake);
            setIntake(res.intake);
            toast.success(`Detected intent (confidence ${(res.confidence * 100).toFixed(0)}%)`);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Intent extraction failed");
        } finally {
            setLoading(false);
        }
    };

    const handleProceed = async () => {
        if (!prompt.trim()) {
            toast.error("Describe what you want to build");
            return;
        }
        setLoading(true, "Analysing requirements…");
        try {
            const clarifyRes = await architectureApi.clarify({ prompt, intake, session_id: null });
            if (clarifyRes.status === "clarification_required") {
                setClarification(clarifyRes.questions);
                setStage("clarification");
                useArchitectureStore.setState({ sessionId: clarifyRes.session_id });
                setLoading(false);
                return;
            }
            setLoading(true, "Retrieving MCP knowledge & generating architecture…");
            const genRes = await architectureApi.generate({
                prompt, intake, clarification_answers: {}, session_id: clarifyRes.session_id,
            });
            if (!genRes.success) {
                toast.error(genRes.message || "Generation failed");
                setLoading(false);
                return;
            }
            applyGeneration(genRes);
            toast.success("Architecture ready");
        } catch (e) {
            toast.error(e?.response?.data?.detail || e.message || "Failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full overflow-hidden" data-testid="intake-panel">
            <div className="px-8 pt-8 pb-5 border-b border-border bg-card">
                <div className="max-w-3xl">
                    <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-2">
                        Architecture Intake
                    </div>
                    <h1 className="text-3xl font-semibold tracking-tight text-foreground">
                        Describe the system you want to build
                    </h1>
                    <p className="text-[13px] text-muted-foreground mt-2 leading-relaxed">
                        NVIDIA NIM reasoning retrieves authoritative context from Microsoft Learn & AWS Knowledge MCP servers, asks clarifying questions, and produces a real production-grade Azure/AWS architecture diagram with official icons.
                    </p>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto px-8 py-6 space-y-6 max-w-4xl">
                <div>
                    <label className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-2 block">
                        Architecture Goal
                    </label>
                    <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        rows={4}
                        data-testid="prompt-textarea"
                        placeholder="e.g. Design a production-grade multi-region microservices platform on Azure AKS for a B2B SaaS, with Cosmos DB, Service Bus, Front Door and Application Gateway WAF."
                        className="w-full bg-card border border-border focus:border-primary rounded-md p-3 text-[13px] text-foreground placeholder:text-muted-foreground outline-none transition-colors resize-none font-mono shadow-card"
                    />
                    <div className="flex justify-end mt-2">
                        <button
                            type="button"
                            onClick={handleAutoDetect}
                            disabled={loading}
                            data-testid="auto-detect-btn"
                            className="text-[11px] uppercase tracking-wider text-muted-foreground hover:text-primary inline-flex items-center gap-1.5 transition-colors disabled:opacity-50"
                        >
                            <Sparkles size={12} /> Auto-detect from prompt
                        </button>
                    </div>
                </div>

                <div>
                    <label className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-3 block">
                        Primary Configuration
                    </label>
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                        {SELECT_FIELDS.slice(0, 6).map((f) => (
                            <SelectField key={f.key} f={f} value={intake[f.key]} onChange={(v) => setIntakeField(f.key, v)} />
                        ))}
                    </div>
                </div>

                <div>
                    <label className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-3 block">
                        Non-functional Requirements
                    </label>
                    <div className="grid grid-cols-2 lg:grid-cols-5 gap-2">
                        {TOGGLE_FIELDS.map((t) => (
                            <button
                                key={t.key}
                                type="button"
                                onClick={() => setIntakeField(t.key, !intake[t.key])}
                                data-testid={`toggle-${t.key}`}
                                className={`flex items-center justify-between rounded-md border px-3 py-2 text-[12px] transition-all ${
                                    intake[t.key]
                                        ? "border-primary bg-primary text-primary-foreground"
                                        : "border-border hover:border-border-strong bg-card text-foreground"
                                }`}
                            >
                                <span>{t.label}</span>
                                <span className="font-mono text-[10px]">{intake[t.key] ? "ON" : "off"}</span>
                            </button>
                        ))}
                    </div>
                </div>

                <div>
                    <label className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-3 block">
                        Compliance
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                        {COMPLIANCE.map((c) => {
                            const active = (intake.compliance || []).includes(c);
                            return (
                                <button
                                    key={c}
                                    type="button"
                                    onClick={() => toggleCompliance(c)}
                                    data-testid={`compliance-${c}`}
                                    className={`text-[11px] px-2.5 py-1 rounded border transition-all font-mono ${
                                        active
                                            ? "border-primary bg-primary text-primary-foreground"
                                            : "border-border hover:border-border-strong text-muted-foreground hover:text-foreground bg-card"
                                    }`}
                                >
                                    {c}
                                </button>
                            );
                        })}
                    </div>
                </div>

                <div>
                    <button
                        type="button"
                        onClick={() => setAdvancedOpen((v) => !v)}
                        data-testid="advanced-toggle"
                        className="inline-flex items-center gap-1 text-[11px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
                    >
                        {advancedOpen ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                        Advanced
                    </button>
                    {advancedOpen && (
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-3 fade-up">
                            {SELECT_FIELDS.slice(6).map((f) => (
                                <SelectField key={f.key} f={f} value={intake[f.key]} onChange={(v) => setIntakeField(f.key, v)} />
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <div className="border-t border-border bg-card px-8 py-4 flex items-center justify-between">
                <div className="text-[11px] text-muted-foreground font-mono">
                    {loading ? progressMessage || "Working…" : "Ready to generate"}
                </div>
                <button
                    type="button"
                    onClick={handleProceed}
                    disabled={loading}
                    data-testid="proceed-btn"
                    className="inline-flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-wait font-medium text-[13px] px-5 py-2 rounded-md transition-all shadow-sm"
                >
                    {loading ? "Generating…" : "Generate Architecture"}
                    <Send size={14} />
                </button>
            </div>
        </div>
    );
}

function SelectField({ f, value, onChange }) {
    const Icon = f.icon;
    return (
        <div>
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground mb-1.5">
                <Icon size={12} />
                <span>{f.label}</span>
            </div>
            <select
                value={value || ""}
                onChange={(e) => onChange(e.target.value || null)}
                data-testid={`select-${f.key}`}
                className="w-full bg-card border border-border hover:border-border-strong focus:border-primary text-foreground text-[12px] rounded-md px-2.5 py-2 outline-none transition-colors font-mono"
            >
                <option value="">—</option>
                {f.options.map((o) => (
                    <option key={o} value={o}>{o}</option>
                ))}
            </select>
        </div>
    );
}
