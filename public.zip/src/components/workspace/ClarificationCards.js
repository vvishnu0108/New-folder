import { useState } from "react";
import { CheckCircle2, Sparkles, ArrowLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import useArchitectureStore from "../../store/useArchitectureStore";
import { architectureApi, streamGenerate } from "../../services/api";

export default function ClarificationCards() {
    const questions = useArchitectureStore((s) => s.clarificationQuestions);
    const answers = useArchitectureStore((s) => s.clarificationAnswers);
    const setAnswer = useArchitectureStore((s) => s.setClarificationAnswer);
    const sessionId = useArchitectureStore((s) => s.sessionId);
    const prompt = useArchitectureStore((s) => s.prompt);
    const intake = useArchitectureStore((s) => s.intake);
    const setStage = useArchitectureStore((s) => s.setStage);
    const setLoading = useArchitectureStore((s) => s.setLoading);
    const applyGeneration = useArchitectureStore((s) => s.applyGeneration);
    const loading = useArchitectureStore((s) => s.loading);
    const progressMessage = useArchitectureStore((s) => s.progressMessage);

    const [activeIdx, setActiveIdx] = useState(0);

    const handleGenerate = async () => {
        setLoading(true, "Retrieving authoritative context from MCP servers…");
        try {
            await new Promise((resolve, reject) => {
                streamGenerate(
                    { prompt, intake, clarification_answers: answers, session_id: sessionId },
                    (evt) => {
                        if (evt.stage === "mcp_retrieval") setLoading(true, evt.message || "Retrieving MCP knowledge…");
                        else if (evt.stage === "mcp_retrieval_done") setLoading(true, evt.message || "MCP knowledge ready");
                        else if (evt.stage === "reasoning") setLoading(true, evt.message || "NIM reasoning & generating diagram code…");
                        else if (evt.stage === "reasoning_done") setLoading(true, evt.message || "Reasoning complete");
                        else if (evt.stage === "diagram_execute") setLoading(true, evt.message || "Rendering enterprise diagram…");
                        else if (evt.stage === "diagram_execute_done") setLoading(true, evt.message || "Diagram rendered");
                        else if (evt.stage === "complete" && evt.payload) {
                            if (evt.payload.success) {
                                applyGeneration(evt.payload);
                                toast.success("Architecture ready");
                                resolve();
                            } else {
                                toast.error(evt.payload.message || "Generation failed");
                                reject(new Error(evt.payload.message || "Failed"));
                            }
                        } else if (evt.stage === "error") {
                            reject(new Error(evt.message || "Stream error"));
                        }
                    }
                );
            });
        } catch (e) {
            toast.error(e?.response?.data?.detail || e.message || "Failed");
        } finally {
            setLoading(false);
        }
    };

    const answeredCount = questions.filter(
        (q) => answers[q.id] !== undefined && answers[q.id] !== "" && answers[q.id] !== null
    ).length;

    return (
        <div className="flex flex-col h-full overflow-hidden" data-testid="clarification-panel">
            <div className="px-8 pt-7 pb-4 border-b border-border bg-card flex items-center justify-between">
                <div>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-2 flex items-center gap-2">
                        <Sparkles size={12} className="text-primary" /> AI Clarification
                    </div>
                    <h2 className="text-2xl font-semibold tracking-tight text-foreground">
                        A few decisions to ground the architecture
                    </h2>
                    <p className="text-[13px] text-muted-foreground mt-1">
                        {answeredCount} of {questions.length} answered
                    </p>
                </div>
                <button
                    type="button"
                    onClick={() => setStage("intake")}
                    data-testid="back-to-intake-btn"
                    className="text-[11px] uppercase tracking-wider text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                >
                    <ArrowLeft size={12} /> Edit Intake
                </button>
            </div>

            <div className="flex-1 overflow-y-auto px-8 py-6 space-y-3 max-w-4xl">
                {questions.map((q, idx) => {
                    const active = idx === activeIdx;
                    const answered = answers[q.id] !== undefined && answers[q.id] !== "" && answers[q.id] !== null;
                    return (
                        <div
                            key={q.id}
                            onClick={() => setActiveIdx(idx)}
                            data-testid={`clarification-card-${q.id}`}
                            className={`rounded-lg border p-4 cursor-pointer transition-all duration-200 fade-up bg-card ${
                                active
                                    ? "border-primary beam-glow"
                                    : "border-border hover:border-border-strong"
                            }`}
                        >
                            <div className="flex items-start gap-3 mb-3">
                                <div
                                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                                        answered ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"
                                    }`}
                                >
                                    Q{idx + 1}
                                </div>
                                <div className="flex-1">
                                    <div className="text-[14px] text-foreground font-medium leading-snug">
                                        {q.question}
                                    </div>
                                    {q.rationale && (
                                        <div className="text-[12px] text-muted-foreground mt-1 leading-relaxed">
                                            {q.rationale}
                                        </div>
                                    )}
                                </div>
                                {answered && <CheckCircle2 size={16} className="text-success" />}
                            </div>

                            {q.type === "boolean" ? (
                                <div className="grid grid-cols-2 gap-2">
                                    {[{ value: "true", label: "Yes" }, { value: "false", label: "No" }].map((opt) => (
                                        <button
                                            key={opt.value}
                                            type="button"
                                            onClick={(e) => { e.stopPropagation(); setAnswer(q.id, opt.value); }}
                                            data-testid={`q-${q.id}-opt-${opt.value}`}
                                            className={`rounded border px-3 py-2 text-[12px] transition-all ${
                                                answers[q.id] === opt.value
                                                    ? "border-primary bg-primary text-primary-foreground"
                                                    : "border-border hover:border-border-strong text-foreground bg-card"
                                            }`}
                                        >
                                            {opt.label}
                                        </button>
                                    ))}
                                </div>
                            ) : q.type === "text" ? (
                                <input
                                    type="text"
                                    value={answers[q.id] || ""}
                                    onClick={(e) => e.stopPropagation()}
                                    onChange={(e) => setAnswer(q.id, e.target.value)}
                                    placeholder="Enter…"
                                    className="w-full bg-background border border-border focus:border-primary rounded px-3 py-2 text-sm text-foreground outline-none"
                                />
                            ) : q.type === "multi" ? (
                                <div className="flex flex-wrap gap-1.5">
                                    {(q.options || []).map((opt) => {
                                        const current = answers[q.id] || [];
                                        const a = Array.isArray(current) && current.includes(opt.value);
                                        return (
                                            <button
                                                key={opt.value}
                                                type="button"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    const next = a ? current.filter((v) => v !== opt.value) : [...current, opt.value];
                                                    setAnswer(q.id, next);
                                                }}
                                                data-testid={`q-${q.id}-opt-${opt.value}`}
                                                className={`text-[11px] px-2.5 py-1 rounded border font-mono ${
                                                    a
                                                        ? "border-primary bg-primary text-primary-foreground"
                                                        : "border-border hover:border-border-strong text-muted-foreground bg-card"
                                                }`}
                                            >
                                                {opt.label}
                                            </button>
                                        );
                                    })}
                                </div>
                            ) : (
                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                                    {(q.options || []).map((opt) => (
                                        <button
                                            key={opt.value}
                                            type="button"
                                            onClick={(e) => { e.stopPropagation(); setAnswer(q.id, opt.value); }}
                                            data-testid={`q-${q.id}-opt-${opt.value}`}
                                            className={`rounded border px-3 py-2 text-[12px] text-left transition-all ${
                                                answers[q.id] === opt.value
                                                    ? "border-primary bg-primary text-primary-foreground"
                                                    : "border-border hover:border-border-strong text-foreground bg-card"
                                            }`}
                                        >
                                            <div className="font-medium">{opt.label}</div>
                                            {opt.recommended && (
                                                <div className="text-[9px] uppercase tracking-wider mt-0.5 opacity-70">recommended</div>
                                            )}
                                            {opt.hint && <div className="text-[10px] opacity-70 mt-0.5">{opt.hint}</div>}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            <div className="border-t border-border bg-card px-8 py-4 flex items-center justify-between">
                <div className="text-[11px] text-muted-foreground font-mono">
                    {loading ? progressMessage || "Working…" : "Answer questions, then generate"}
                </div>
                <button
                    type="button"
                    onClick={handleGenerate}
                    disabled={loading}
                    data-testid="generate-from-clarification-btn"
                    className="inline-flex items-center gap-2 bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-wait text-[13px] font-medium px-5 py-2 rounded-md transition-all shadow-sm"
                >
                    {loading ? "Generating…" : "Generate Architecture"}
                    <ChevronRight size={14} />
                </button>
            </div>
        </div>
    );
}
