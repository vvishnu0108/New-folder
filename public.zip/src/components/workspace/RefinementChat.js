import { useEffect, useRef, useState } from "react";
import { Send, Wand2, ChevronUp, ChevronDown } from "lucide-react";
import { toast } from "sonner";
import useArchitectureStore from "../../store/useArchitectureStore";
import { architectureApi } from "../../services/api";

const QUICK_ACTIONS = [
    { label: "Add monitoring", instruction: "Add a comprehensive observability/monitoring layer (metrics, logs, tracing, dashboards, alerts)." },
    { label: "Optimize cost", instruction: "Optimize the architecture for cost: lower-tier SKUs where safe, spot/preemptible compute, lifecycle policies." },
    { label: "Multi-region", instruction: "Convert this to an active-active multi-region architecture with global routing and replicated data." },
    { label: "Harden security", instruction: "Improve security posture: WAF, private endpoints, customer-managed keys, zero-trust networking, secret management." },
    { label: "Add DR", instruction: "Add a disaster recovery strategy with cross-region replication, RPO/RTO targets and runbook automation." },
];

export default function RefinementChat({ drawioRef, expanded = true, onToggle }) {
    const sessionId = useArchitectureStore((s) => s.sessionId);
    const conversation = useArchitectureStore((s) => s.conversation);
    const applyGeneration = useArchitectureStore((s) => s.applyGeneration);
    const addConversation = useArchitectureStore((s) => s.addConversation);
    const setLoading = useArchitectureStore((s) => s.setLoading);
    const loading = useArchitectureStore((s) => s.loading);
    const drawioXml = useArchitectureStore((s) => s.drawioXml);

    const [input, setInput] = useState("");
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, [conversation]);

    const send = async (instruction) => {
        if (!instruction.trim() || !sessionId) return;
        addConversation("user", instruction);
        setInput("");
        setLoading(true, "Refining architecture…");
        try {
            let currentXml = drawioXml;
            if (drawioRef?.current?.exportXml) {
                const xml = await drawioRef.current.exportXml();
                if (xml) currentXml = xml;
            }
            const res = await architectureApi.refine({
                session_id: sessionId,
                instruction,
                current_drawio_xml: currentXml,
            });
            if (res.success) {
                applyGeneration(res);
                addConversation("assistant", res.message || "Architecture refined");
                toast.success("Architecture updated");
            } else {
                addConversation("assistant", `Failed: ${res.message}`);
                toast.error(res.message || "Refinement failed");
            }
        } catch (e) {
            const msg = e?.response?.data?.detail || e.message || "Failed";
            addConversation("assistant", `Error: ${msg}`);
            toast.error(msg);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full" data-testid="refinement-chat">
            <div className="px-4 py-2.5 flex items-center justify-between border-b border-border bg-muted/30">
                <div className="flex items-center gap-2">
                    <Wand2 size={12} className="text-primary" />
                    <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-semibold">
                        Refinement Chat
                    </span>
                </div>
                <button
                    type="button"
                    onClick={onToggle}
                    data-testid="refinement-toggle"
                    className="p-1 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors"
                    title={expanded ? "Collapse" : "Expand"}
                >
                    {expanded ? <ChevronDown size={13} /> : <ChevronUp size={13} />}
                </button>
            </div>

            {expanded && (
                <>
                    <div className="px-3 py-2 border-b border-border bg-card">
                        <div className="flex flex-wrap gap-1">
                            {QUICK_ACTIONS.map((a) => (
                                <button
                                    key={a.label}
                                    type="button"
                                    onClick={() => send(a.instruction)}
                                    disabled={loading || !sessionId}
                                    data-testid={`quick-${a.label.replace(/\s+/g, "-").toLowerCase()}`}
                                    className="text-[10px] uppercase tracking-wider px-2 py-1 rounded border border-border hover:border-primary hover:text-primary text-muted-foreground hover:bg-primary/5 disabled:opacity-40 transition-colors"
                                >
                                    {a.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div
                        ref={scrollRef}
                        className="flex-1 overflow-y-auto px-4 py-3 space-y-2 bg-card"
                        data-testid="refinement-messages"
                    >
                        {conversation.length === 0 && (
                            <div className="text-[12px] text-muted-foreground">
                                Ask the agent to refine the architecture, or use a quick action above.
                            </div>
                        )}
                        {conversation.map((m, i) => (
                            <div
                                key={i}
                                className={`max-w-[85%] rounded-md px-3 py-2 text-[12px] leading-relaxed fade-up ${
                                    m.role === "user"
                                        ? "ml-auto bg-primary text-primary-foreground"
                                        : "bg-muted text-foreground border border-border"
                                }`}
                            >
                                {m.content}
                            </div>
                        ))}
                    </div>

                    <div className="border-t border-border p-2.5 bg-card">
                        <div className="flex items-center gap-2">
                            <input
                                type="text"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyDown={(e) => e.key === "Enter" && send(input)}
                                placeholder={sessionId ? "Add caching layer with Redis…" : "Generate an architecture first"}
                                disabled={!sessionId || loading}
                                data-testid="refinement-input"
                                className="flex-1 bg-background border border-border focus:border-primary rounded px-3 py-1.5 text-[13px] text-foreground outline-none disabled:opacity-50 transition-colors"
                            />
                            <button
                                type="button"
                                onClick={() => send(input)}
                                disabled={!sessionId || loading || !input.trim()}
                                data-testid="refinement-send-btn"
                                className="bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-40 p-2 rounded transition-all"
                            >
                                <Send size={13} />
                            </button>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}
