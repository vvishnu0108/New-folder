import { useRef, useState } from "react";
import { PanelTop } from "lucide-react";
import IntakePanel from "./IntakePanel";
import ClarificationCards from "./ClarificationCards";
import ReasoningTimeline from "./ReasoningTimeline";
import RefinementChat from "./RefinementChat";
import DrawIOCanvas from "../drawio/DrawIOCanvas";
import useArchitectureStore from "../../store/useArchitectureStore";

export default function CenterWorkspace({ canvasFullscreen = false }) {
    const stage = useArchitectureStore((s) => s.stage);
    const drawioXml = useArchitectureStore((s) => s.drawioXml);
    const reasoning = useArchitectureStore((s) => s.reasoning);
    const updateDrawioXml = useArchitectureStore((s) => s.updateDrawioXml);
    const loading = useArchitectureStore((s) => s.loading);
    const progressMessage = useArchitectureStore((s) => s.progressMessage);
    const drawioRef = useRef(null);
    const [chatExpanded, setChatExpanded] = useState(true);

    if (stage === "intake" && !drawioXml) {
        return (
            <div className="flex-1 flex flex-col bg-background relative overflow-hidden" data-testid="center-stage-intake">
                <LoadingOverlay loading={loading} message={progressMessage} />
                <IntakePanel />
            </div>
        );
    }

    if (stage === "clarification" && !drawioXml) {
        return (
            <div className="flex-1 flex flex-col bg-background relative overflow-hidden" data-testid="center-stage-clarification">
                <LoadingOverlay loading={loading} message={progressMessage} />
                <ClarificationCards />
            </div>
        );
    }

    // Workspace view (after generation)
    return (
        <div className="flex-1 flex flex-col bg-background relative overflow-hidden" data-testid="center-stage-workspace">
            <LoadingOverlay loading={loading} message={progressMessage} />

            {canvasFullscreen ? (
                /* Distraction-free canvas */
                <div className="absolute inset-0 z-10 p-4 bg-background">
                    <DrawIOCanvas
                        ref={drawioRef}
                        diagramXml={drawioXml}
                        onDiagramChange={updateDrawioXml}
                    />
                </div>
            ) : (
                <div className="flex flex-1 overflow-hidden">
                    {/* Reasoning rail (lighter, collapsible internally if needed) */}
                    <div className="w-72 shrink-0 border-r border-border bg-card/50 overflow-y-auto">
                        <div className="px-4 py-3 border-b border-border sticky top-0 bg-card/80 backdrop-blur z-10">
                            <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                                Reasoning
                            </div>
                            <div className="text-[12px] text-foreground mt-0.5">
                                AI Decision Timeline
                            </div>
                        </div>
                        <div className="px-3 pb-4">
                            <ReasoningTimeline nodes={reasoning} />
                        </div>
                    </div>

                    {/* Canvas + chat stacked vertically */}
                    <div className="flex-1 flex flex-col overflow-hidden p-3 gap-3">
                        <div className={`flex-1 min-h-0 ${chatExpanded ? "" : "flex-[2_1_0%]"}`}>
                            <DrawIOCanvas
                                ref={drawioRef}
                                diagramXml={drawioXml}
                                onDiagramChange={updateDrawioXml}
                            />
                        </div>
                        <div
                            className="surface-card rounded-lg overflow-hidden"
                            style={{ height: chatExpanded ? "320px" : "48px" }}
                        >
                            <RefinementChat
                                drawioRef={drawioRef}
                                expanded={chatExpanded}
                                onToggle={() => setChatExpanded((v) => !v)}
                            />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

function LoadingOverlay({ loading, message }) {
    if (!loading) return null;
    return (
        <div
            className="absolute inset-0 z-30 flex items-center justify-center bg-background/70 backdrop-blur-sm"
            data-testid="loading-overlay"
        >
            <div className="rounded-lg border border-border bg-card px-6 py-4 flex items-center gap-3 shadow-floating">
                <div className="h-6 w-6 border-2 border-muted border-t-primary rounded-full animate-spin" />
                <div>
                    <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                        Working
                    </div>
                    <div className="text-[13px] text-foreground font-medium">
                        {message || "Processing…"}
                    </div>
                </div>
            </div>
        </div>
    );
}
