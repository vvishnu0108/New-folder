import { useState } from "react";
import { ChevronDown, ChevronRight, CircleDot } from "lucide-react";

const categoryColor = (cat) => {
    switch (cat) {
        case "compute":       return "border-azure/40 text-azure bg-azure/10";
        case "data":          return "border-success/40 text-success bg-success/10";
        case "networking":    return "border-info/40 text-info bg-info/10";
        case "security":      return "border-danger/40 text-danger bg-danger/10";
        case "observability": return "border-warning/40 text-warning bg-warning/10";
        case "cost":          return "border-warning/40 text-warning bg-warning/10";
        default:              return "border-border text-muted-foreground bg-muted/30";
    }
};

const providerBadge = (p) =>
    p === "azure" ? "text-azure" : p === "aws" ? "text-aws" : p === "gcp" ? "text-gcp" : "text-muted-foreground";

export default function ReasoningTimeline({ nodes = [] }) {
    const [expanded, setExpanded] = useState({});

    if (!nodes.length) {
        return (
            <div className="text-[12px] text-muted-foreground px-2 py-4" data-testid="reasoning-empty">
                Generate an architecture to see the AI decision chain.
            </div>
        );
    }

    return (
        <div className="pl-4 border-l-2 border-border space-y-2.5 py-3" data-testid="reasoning-timeline">
            {nodes.map((n, idx) => {
                const open = expanded[n.id] !== false; // default open
                return (
                    <div
                        key={n.id || idx}
                        data-testid={`reasoning-${n.id}`}
                        className="relative fade-up"
                        style={{ animationDelay: `${idx * 40}ms` }}
                    >
                        <div className="absolute -left-[22px] top-1.5 h-2.5 w-2.5 rounded-full bg-primary ring-4 ring-card pulse-dot" />
                        <button
                            type="button"
                            onClick={() => setExpanded((s) => ({ ...s, [n.id]: !open }))}
                            className="w-full text-left rounded-md border border-border hover:border-border-strong bg-card hover:bg-muted/40 px-3 py-2 transition-all"
                        >
                            <div className="flex items-start gap-2">
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                                        {n.category && (
                                            <span className={`text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded border font-mono ${categoryColor(n.category)}`}>
                                                {n.category}
                                            </span>
                                        )}
                                        {n.provider && (
                                            <span className={`text-[10px] uppercase font-mono ${providerBadge(n.provider)}`}>
                                                {n.provider}
                                            </span>
                                        )}
                                        {typeof n.confidence === "number" && (
                                            <span className="text-[10px] font-mono text-muted-foreground">
                                                {Math.round(n.confidence * 100)}%
                                            </span>
                                        )}
                                    </div>
                                    <div className="text-[13px] font-medium text-foreground leading-snug">
                                        {n.title}
                                    </div>
                                    {open && (
                                        <div className="mt-1.5 text-[12px] text-muted-foreground leading-relaxed">
                                            {n.explanation}
                                            {n.impacted_services?.length > 0 && (
                                                <div className="mt-2 flex flex-wrap gap-1">
                                                    {n.impacted_services.map((s) => (
                                                        <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted text-foreground border border-border">
                                                            {s}
                                                        </span>
                                                    ))}
                                                </div>
                                            )}
                                            {n.mcp_source && (
                                                <div className="mt-1.5 text-[10px] uppercase tracking-wider text-muted-foreground inline-flex items-center gap-1">
                                                    <CircleDot size={10} /> source: {n.mcp_source}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                                {open ? <ChevronDown size={13} className="text-muted-foreground mt-1" /> : <ChevronRight size={13} className="text-muted-foreground mt-1" />}
                            </div>
                        </button>
                    </div>
                );
            })}
        </div>
    );
}
