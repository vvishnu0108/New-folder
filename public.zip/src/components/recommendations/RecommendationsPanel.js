import { ShieldCheck, DollarSign, TrendingUp, BookOpen, Cpu } from "lucide-react";

const ICONS = {
    security: ShieldCheck,
    cost: DollarSign,
    scalability: TrendingUp,
    best_practice: BookOpen,
    service: Cpu,
};

const IMPACT_COLOR = {
    high: "text-success border-success/40 bg-success/10",
    medium: "text-warning border-warning/40 bg-warning/10",
    low: "text-muted-foreground border-border bg-muted/30",
};

export default function RecommendationsPanel({ items = [], filter }) {
    const list = filter ? items.filter((r) => r.category === filter) : items;
    if (!list.length) return <div className="text-[12px] text-muted-foreground">No recommendations available.</div>;
    return (
        <div className="space-y-2" data-testid={`recommendations-${filter || "all"}`}>
            {list.map((r) => {
                const Icon = ICONS[r.category] || BookOpen;
                return (
                    <div key={r.id} className="rounded-md border border-border bg-card px-3 py-2 fade-up">
                        <div className="flex items-start gap-2">
                            <Icon size={13} className="text-muted-foreground mt-0.5 shrink-0" />
                            <div className="flex-1">
                                <div className="flex items-center justify-between gap-2">
                                    <span className="text-[12px] font-medium text-foreground leading-snug">{r.title}</span>
                                    <span className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded border ${IMPACT_COLOR[r.impact] || IMPACT_COLOR.medium}`}>
                                        {r.impact}
                                    </span>
                                </div>
                                <div className="text-[11px] text-muted-foreground leading-relaxed mt-0.5">{r.description}</div>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
