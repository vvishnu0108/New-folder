import { useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import useArchitectureStore from "../../store/useArchitectureStore";
import MetadataPanel from "../metadata/MetadataPanel";
import ValidationPanel from "../validation/ValidationPanel";
import TradeoffsPanel from "../tradeoffs/TradeoffsPanel";
import RecommendationsPanel from "../recommendations/RecommendationsPanel";
import MCPSourcesPanel from "../mcp/MCPSourcesPanel";

function Section({ title, count, defaultOpen = true, testId, children }) {
    const [open, setOpen] = useState(defaultOpen);
    return (
        <div className="border-b border-border last:border-b-0">
            <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                data-testid={testId}
                className="w-full px-4 py-2.5 flex items-center justify-between hover:bg-muted/60 transition-colors"
            >
                <span className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground font-semibold flex items-center gap-2">
                    {open ? <ChevronDown size={10} /> : <ChevronRight size={10} />}
                    {title}
                </span>
                {typeof count === "number" && (
                    <span className="text-[10px] font-mono text-muted-foreground/70">{count}</span>
                )}
            </button>
            {open && <div className="px-3 pb-4 fade-up">{children}</div>}
        </div>
    );
}

export default function RightSidebar() {
    const metadata = useArchitectureStore((s) => s.metadata);
    const score = useArchitectureStore((s) => s.architectureScore);
    const validation = useArchitectureStore((s) => s.validation);
    const tradeoffs = useArchitectureStore((s) => s.tradeoffs);
    const recommendations = useArchitectureStore((s) => s.recommendations);
    const mcpSources = useArchitectureStore((s) => s.mcpSources);

    const security = recommendations.filter((r) => r.category === "security");
    const cost = recommendations.filter((r) => r.category === "cost");
    const scalability = recommendations.filter((r) => r.category === "scalability");
    const bestPractice = recommendations.filter(
        (r) => r.category === "best_practice" || r.category === "service"
    );

    return (
        <aside
            className="w-full h-full border-l border-border bg-card flex flex-col overflow-hidden"
            data-testid="right-sidebar"
        >
            <div className="px-4 py-3 border-b border-border">
                <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                    Context Panel
                </div>
                <div className="text-[13px] font-medium text-foreground mt-0.5">
                    Architecture Insights
                </div>
            </div>

            <div className="flex-1 overflow-y-auto">
                <Section title="Metadata" testId="section-metadata">
                    <MetadataPanel metadata={metadata} score={score} />
                </Section>
                <Section title="Validation" count={validation.length} testId="section-validation">
                    <ValidationPanel items={validation} />
                </Section>
                <Section title="Tradeoffs" count={tradeoffs.length} defaultOpen={false} testId="section-tradeoffs">
                    <TradeoffsPanel items={tradeoffs} />
                </Section>
                <Section title="Security" count={security.length} defaultOpen={false} testId="section-security">
                    <RecommendationsPanel items={security} filter="security" />
                </Section>
                <Section title="Cost Optimization" count={cost.length} defaultOpen={false} testId="section-cost">
                    <RecommendationsPanel items={cost} filter="cost" />
                </Section>
                <Section title="Scalability" count={scalability.length} defaultOpen={false} testId="section-scalability">
                    <RecommendationsPanel items={scalability} filter="scalability" />
                </Section>
                <Section title="Best Practices" count={bestPractice.length} defaultOpen={false} testId="section-bestpractice">
                    <RecommendationsPanel items={bestPractice} />
                </Section>
                <Section title="MCP Context" count={mcpSources.length} defaultOpen={false} testId="section-mcp-context">
                    <MCPSourcesPanel sources={mcpSources} />
                </Section>
            </div>
        </aside>
    );
}
