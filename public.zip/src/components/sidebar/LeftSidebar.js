import { useEffect, useState } from "react";
import {
    Library, FolderOpen, Cloud, History, Globe, Plus, ChevronDown, ChevronRight,
} from "lucide-react";
import useArchitectureStore from "../../store/useArchitectureStore";
import { architectureApi, mcpApi } from "../../services/api";

const SectionHeader = ({ icon: Icon, label, count, open, onToggle, testId }) => (
    <button
        type="button"
        onClick={onToggle}
        data-testid={testId}
        className="w-full flex items-center justify-between px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground transition-colors"
    >
        <span className="flex items-center gap-2">
            {open ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
            <Icon size={12} />
            <span>{label}</span>
        </span>
        {typeof count === "number" && (
            <span className="text-muted-foreground/70 font-mono text-[10px]">{count}</span>
        )}
    </button>
);

export default function LeftSidebar() {
    const reset = useArchitectureStore((s) => s.reset);
    const setPrompt = useArchitectureStore((s) => s.setPrompt);
    const setIntake = useArchitectureStore((s) => s.setIntake);
    const setStage = useArchitectureStore((s) => s.setStage);
    const templates = useArchitectureStore((s) => s.templates);
    const setTemplates = useArchitectureStore((s) => s.setTemplates);
    const mcpSourcesStatus = useArchitectureStore((s) => s.mcpSourcesStatus);
    const setMcpStatus = useArchitectureStore((s) => s.setMcpStatus);
    const sessionId = useArchitectureStore((s) => s.sessionId);

    const [open, setOpen] = useState({
        templates: true,
        providers: false,
        mcp: true,
        sessions: false,
    });
    const toggle = (k) => setOpen((s) => ({ ...s, [k]: !s[k] }));

    const [recentSessions, setRecentSessions] = useState([]);

    useEffect(() => {
        architectureApi.listTemplates().then(setTemplates).catch(() => {});
        mcpApi.listSources().then(setMcpStatus).catch(() => {});
        architectureApi.listSessions().then(setRecentSessions).catch(() => {});
    }, [setTemplates, setMcpStatus]);

    useEffect(() => {
        if (sessionId) {
            architectureApi.listSessions().then(setRecentSessions).catch(() => {});
        }
    }, [sessionId]);

    const handleTemplate = (tpl) => {
        reset();
        setPrompt(tpl.prompt);
        setIntake({ cloud_provider: tpl.provider, architecture_type: tpl.category });
        setStage("intake");
    };

    const providerChip = (p) =>
        p === "azure" ? "chip-azure" : p === "aws" ? "chip-aws" : "chip-gcp";

    return (
        <aside
            className="w-72 h-full border-r border-border bg-card flex flex-col"
            data-testid="left-sidebar"
        >
            <div className="px-4 py-3 border-b border-border">
                <button
                    type="button"
                    onClick={reset}
                    data-testid="new-architecture-btn"
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 text-[12px] font-medium text-primary-foreground bg-primary hover:bg-primary/90 rounded-md transition-colors shadow-sm focus-ring"
                >
                    <Plus size={14} /> New Architecture
                </button>
            </div>

            <div className="flex-1 overflow-y-auto">
                <div className="py-2">
                    <SectionHeader
                        icon={Library}
                        label="Templates"
                        count={templates.length}
                        open={open.templates}
                        onToggle={() => toggle("templates")}
                        testId="section-templates-toggle"
                    />
                    {open.templates && (
                        <div className="px-2 space-y-1 pb-2 fade-up">
                            {templates.map((t) => (
                                <button
                                    type="button"
                                    key={t.id}
                                    onClick={() => handleTemplate(t)}
                                    data-testid={`template-${t.id}`}
                                    className="w-full text-left rounded-md border border-border hover:border-border-strong hover:bg-muted px-3 py-2 transition-all duration-150 focus-ring"
                                >
                                    <div className="flex items-center justify-between mb-1 gap-2">
                                        <span className="text-[12px] font-medium text-foreground leading-tight">
                                            {t.name}
                                        </span>
                                        <span className={`text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded font-mono ${providerChip(t.provider)}`}>
                                            {t.provider}
                                        </span>
                                    </div>
                                    <div className="text-[11px] text-muted-foreground leading-snug line-clamp-2">
                                        {t.description}
                                    </div>
                                </button>
                            ))}
                        </div>
                    )}
                </div>

                <div className="py-1 border-t border-border">
                    <SectionHeader
                        icon={Cloud}
                        label="Cloud Providers"
                        open={open.providers}
                        onToggle={() => toggle("providers")}
                        testId="section-providers-toggle"
                    />
                    {open.providers && (
                        <div className="px-3 pb-3 space-y-1 fade-up">
                            {["azure", "aws", "gcp"].map((p) => (
                                <div
                                    key={p}
                                    className={`flex items-center justify-between rounded px-3 py-1.5 text-[10px] uppercase tracking-wider font-semibold font-mono ${providerChip(p)}`}
                                >
                                    <span>{p}</span>
                                    <span className="opacity-60 normal-case tracking-normal">
                                        {p === "gcp" ? "placeholder" : "available"}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="py-1 border-t border-border">
                    <SectionHeader
                        icon={Globe}
                        label="MCP Sources"
                        count={mcpSourcesStatus.length}
                        open={open.mcp}
                        onToggle={() => toggle("mcp")}
                        testId="section-mcp-toggle"
                    />
                    {open.mcp && (
                        <div className="px-2 pb-2 space-y-1 fade-up">
                            {mcpSourcesStatus.map((s) => (
                                <div
                                    key={s.id}
                                    data-testid={`mcp-source-${s.id}`}
                                    className="rounded-md border border-border bg-subtle px-3 py-2"
                                >
                                    <div className="flex items-center justify-between gap-2">
                                        <span className="text-[12px] text-foreground truncate">
                                            {s.name}
                                        </span>
                                        <span
                                            className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded shrink-0 ${
                                                s.status === "online"
                                                    ? "bg-success/15 text-success"
                                                    : s.status === "offline"
                                                    ? "bg-destructive/15 text-destructive"
                                                    : "bg-muted text-muted-foreground"
                                            }`}
                                        >
                                            {s.status}
                                        </span>
                                    </div>
                                    {s.tools?.length > 0 && (
                                        <div className="mt-1 text-[10px] text-muted-foreground font-mono truncate">
                                            {s.tools.slice(0, 2).join(", ")}
                                            {s.tools.length > 2 && ` +${s.tools.length - 2}`}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="py-1 border-t border-border">
                    <SectionHeader
                        icon={History}
                        label="Recent Sessions"
                        count={recentSessions.length}
                        open={open.sessions}
                        onToggle={() => toggle("sessions")}
                        testId="section-sessions-toggle"
                    />
                    {open.sessions && (
                        <div className="px-2 pb-3 space-y-1 fade-up">
                            {recentSessions.length === 0 ? (
                                <div className="text-[11px] text-muted-foreground px-2 py-1">
                                    No sessions yet
                                </div>
                            ) : (
                                recentSessions.map((s) => (
                                    <div
                                        key={s.session_id}
                                        className="rounded-md border border-border bg-subtle px-3 py-2 text-[11px] text-foreground"
                                    >
                                        <div className="font-mono text-[10px] text-muted-foreground">
                                            #{s.session_id}
                                        </div>
                                        <div className="truncate">
                                            {s.prompt || "(untitled)"}
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>
            </div>
        </aside>
    );
}
