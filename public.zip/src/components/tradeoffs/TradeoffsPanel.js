import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from "recharts";
import { useTheme } from "../../contexts/ThemeContext";

export default function TradeoffsPanel({ items = [] }) {
    const { theme } = useTheme();
    const isDark = theme === "dark";
    const gridColor = isDark ? "#3f3f46" : "#D1D1D1";
    const tickColor = isDark ? "#a1a1aa" : "#6B6B6B";
    const radarStroke = "#E2231A";
    const radarFill = "#E2231A";

    if (!items.length) return <div className="text-[12px] text-muted-foreground">No tradeoff analysis yet.</div>;

    return (
        <div className="space-y-3" data-testid="tradeoffs-panel">
            {items.map((t, idx) => {
                const data = t.points.map((p) => ({ dimension: p.dimension, score: p.score }));
                return (
                    <div
                        key={idx}
                        data-testid={`tradeoff-${idx}`}
                        className="rounded-md border border-border bg-card p-3 fade-up"
                    >
                        <div className="text-[12px] text-foreground font-medium leading-snug">{t.title}</div>
                        <div className="text-[11px] text-muted-foreground leading-relaxed mb-2 mt-0.5">{t.summary}</div>
                        <div className="h-44 -mx-2">
                            <ResponsiveContainer width="100%" height="100%">
                                <RadarChart data={data} outerRadius="70%">
                                    <PolarGrid stroke={gridColor} strokeDasharray="2 4" />
                                    <PolarAngleAxis dataKey="dimension" tick={{ fill: tickColor, fontSize: 10, fontFamily: "IBM Plex Mono" }} />
                                    <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: tickColor, fontSize: 9 }} stroke={gridColor} />
                                    <Radar dataKey="score" stroke={radarStroke} fill={radarFill} fillOpacity={0.18} strokeWidth={1.5} />
                                </RadarChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                            {t.points.map((p, i) => (
                                <div key={i} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-muted border border-border text-foreground">
                                    {p.dimension}: {p.score}
                                </div>
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
