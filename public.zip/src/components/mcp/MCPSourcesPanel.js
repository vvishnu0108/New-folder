import { Globe } from "lucide-react";

export default function MCPSourcesPanel({ sources = [] }) {
    if (!sources.length) return <div className="text-[12px] text-muted-foreground">No MCP context retrieved.</div>;
    return (
        <div className="space-y-2" data-testid="mcp-sources-panel">
            {sources.map((s, idx) => (
                <div key={idx} className="rounded-md border border-border bg-card px-3 py-2">
                    <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                            <Globe size={12} className="text-muted-foreground" />
                            <span className="text-[11px] uppercase tracking-wider text-foreground font-mono">{s.provider}</span>
                        </div>
                        <span className="text-[10px] font-mono text-muted-foreground">{s.tool}</span>
                    </div>
                    <div className="text-[11px] text-muted-foreground leading-relaxed">{s.summary}</div>
                    {s.snippets?.length > 0 && (
                        <div className="mt-2 space-y-1">
                            {s.snippets.slice(0, 2).map((sn, i) => (
                                <div key={i} className="text-[10px] font-mono text-muted-foreground bg-muted/40 border border-border rounded px-2 py-1 leading-relaxed line-clamp-2">
                                    {sn}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
}
