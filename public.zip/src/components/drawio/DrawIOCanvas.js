import { useEffect, useRef, useState, useImperativeHandle, forwardRef } from "react";
import { Maximize2, Minimize2, RefreshCcw, Check } from "lucide-react";
import { useTheme } from "../../contexts/ThemeContext";
import ExportMenu from "./ExportMenu";
import SnapshotMenu from "./SnapshotMenu";

const buildDrawioUrl = (theme) => {
    const url = new URL("https://embed.diagrams.net/");
    url.searchParams.set("embed", "1");
    url.searchParams.set("ui", "kennedy");
    url.searchParams.set("proto", "json");
    url.searchParams.set("configure", "1");
    url.searchParams.set("spin", "1");
    url.searchParams.set("noSaveBtn", "1");
    url.searchParams.set("noExitBtn", "1");
    url.searchParams.set("saveAndExit", "0");
    if (theme === "dark") {
        url.searchParams.set("dark", "1");
    } else {
        url.searchParams.set("dark", "0");
    }
    return url.toString();
};

const DrawIOCanvas = forwardRef(function DrawIOCanvas(
    { diagramXml, onDiagramChange, onReady, className = "" },
    ref
) {
    const iframeRef = useRef(null);
    const [isReady, setIsReady] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [savedAt, setSavedAt] = useState(null);
    const [autosaving, setAutosaving] = useState(false);
    const exportResolveRef = useRef(null);
    const containerRef = useRef(null);
    const { theme } = useTheme();
    const [iframeKey, setIframeKey] = useState(0);

    // Reload iframe when theme changes
    useEffect(() => {
        setIframeKey((k) => k + 1);
        setIsReady(false);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [theme]);

    useEffect(() => {
        const handler = (event) => {
            if (!event.data || typeof event.data !== "string") return;
            let msg;
            try {
                msg = JSON.parse(event.data);
            } catch {
                return;
            }

            if (msg.event === "configure") {
                const isDark = theme === "dark";
                iframeRef.current?.contentWindow?.postMessage(
                    JSON.stringify({
                        action: "configure",
                        config: {
                            defaultFonts: ["Inter", "IBM Plex Sans", "Helvetica"],
                            css: isDark
                                ? `
                                body, html { background:#0c0c0e !important; color:#fafafa !important; }
                                .geMenubar, .geToolbar { background:#18181b !important; border-color:#27272a !important; color:#fafafa !important; }
                                .geSidebarContainer, .geSidebar, .gePalette { background:#18181b !important; color:#fafafa !important; border-color:#27272a !important; }
                                .geDiagramBackdrop, .geDiagramContainer { background:#0c0c0e !important; }
                                .mxWindow, .mxWindowPane { background:#18181b !important; color:#fafafa !important; }
                                .mxWindowTitle { background:#27272a !important; color:#fafafa !important; }
                                .geFormatContainer { background:#18181b !important; color:#fafafa !important; }
                                ::-webkit-scrollbar-track { background:#18181b !important; }
                                ::-webkit-scrollbar-thumb { background:#3f3f46 !important; }
                            `
                                : `
                                body, html { background:#FFFFFF !important; color:#1A1A1A !important; }
                                .geMenubar { background:#FFFFFF !important; border-bottom:2px solid #E2231A !important; color:#1A1A1A !important; }
                                .geToolbar { background:#F7F7F7 !important; color:#1A1A1A !important; border-color:#E5E5E5 !important; }
                                .geSidebarContainer, .geSidebar, .gePalette { background:#FFFFFF !important; color:#1A1A1A !important; border-color:#E5E5E5 !important; }
                                .geDiagramBackdrop, .geDiagramContainer { background:#FFFFFF !important; }
                                .mxWindow, .mxWindowPane { background:#FFFFFF !important; color:#1A1A1A !important; }
                                .mxWindowTitle { background:#F7F7F7 !important; color:#1A1A1A !important; }
                                .geFormatContainer { background:#FFFFFF !important; color:#1A1A1A !important; }
                                ::-webkit-scrollbar-track { background:#F7F7F7 !important; }
                                ::-webkit-scrollbar-thumb { background:#D1D1D1 !important; }
                            `,
                        },
                    }),
                    "*"
                );
            }

            if (msg.event === "init") {
                setIsReady(true);
                onReady && onReady();
                if (diagramXml) {
                    iframeRef.current?.contentWindow?.postMessage(
                        JSON.stringify({ action: "load", xml: diagramXml, autosave: 1 }),
                        "*"
                    );
                }
            }

            if ((msg.event === "autosave" || msg.event === "save") && msg.xml) {
                onDiagramChange && onDiagramChange(msg.xml);
                setAutosaving(true);
                setSavedAt(new Date());
                setTimeout(() => setAutosaving(false), 1200);
            }

            if (msg.event === "export" && (msg.data || msg.xml)) {
                if (exportResolveRef.current) {
                    exportResolveRef.current(msg.xml || msg.data);
                    exportResolveRef.current = null;
                }
            }
        };
        window.addEventListener("message", handler);
        return () => window.removeEventListener("message", handler);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [theme]);

    useEffect(() => {
        if (isReady && diagramXml && iframeRef.current?.contentWindow) {
            iframeRef.current.contentWindow.postMessage(
                JSON.stringify({ action: "load", xml: diagramXml, autosave: 1 }),
                "*"
            );
        }
    }, [diagramXml, isReady]);

    useImperativeHandle(ref, () => ({
        exportXml: () =>
            new Promise((resolve) => {
                if (!iframeRef.current?.contentWindow) return resolve(null);
                exportResolveRef.current = resolve;
                iframeRef.current.contentWindow.postMessage(
                    JSON.stringify({ action: "export", format: "xml" }),
                    "*"
                );
                setTimeout(() => {
                    if (exportResolveRef.current) {
                        exportResolveRef.current(null);
                        exportResolveRef.current = null;
                    }
                }, 4000);
            }),
    }));

    const refresh = () => setIframeKey((k) => k + 1);

    const toggleFullscreen = () => setIsFullscreen((f) => !f);

    return (
        <div
            ref={containerRef}
            data-testid="drawio-canvas"
            className={`relative flex flex-col rounded-lg border border-border bg-card shadow-card overflow-hidden ${
                isFullscreen ? "fixed inset-4 z-50 shadow-floating" : "h-full"
            } ${className}`}
        >
            <div className="flex items-center justify-between border-b border-border bg-card/80 backdrop-blur px-3 py-2">
                <div className="flex items-center gap-2.5">
                    <span className={`h-1.5 w-1.5 rounded-full ${isReady ? "bg-success pulse-dot" : "bg-muted-foreground"}`} />
                    <span className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                        Diagram Canvas
                    </span>
                    {savedAt && (
                        <span className={`flex items-center gap-1 text-[10px] font-mono text-success transition-opacity ${autosaving ? "opacity-100" : "opacity-60"}`}>
                            <Check size={11} />
                            <span>autosaved</span>
                        </span>
                    )}
                </div>
                <div className="flex items-center gap-0.5">
                    <SnapshotMenu drawioRef={ref} />
                    <ExportMenu iframeRef={iframeRef} diagramXml={diagramXml} />
                    <button
                        type="button"
                        onClick={refresh}
                        data-testid="drawio-refresh-btn"
                        className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors"
                        title="Refresh editor"
                    >
                        <RefreshCcw size={13} />
                    </button>
                    <button
                        type="button"
                        onClick={toggleFullscreen}
                        data-testid="drawio-fullscreen-btn"
                        className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors"
                        title="Fullscreen"
                    >
                        {isFullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
                    </button>
                </div>
            </div>
            <div className="relative flex-1 bg-card">
                {!diagramXml && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 workspace-empty-bg pointer-events-none">
                        <div className="text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
                            Awaiting Architecture
                        </div>
                        <div className="text-foreground text-sm max-w-md text-center px-6">
                            Submit your intake to generate a production-grade diagram.
                        </div>
                    </div>
                )}
                <iframe
                    key={iframeKey}
                    ref={iframeRef}
                    title="Draw.IO editor"
                    src={buildDrawioUrl(theme)}
                    className="w-full h-full border-0"
                    style={{ opacity: diagramXml ? 1 : 0.4 }}
                />
            </div>
        </div>
    );
});

export default DrawIOCanvas;
