import { useEffect, useState } from "react";
import { History, Camera, RotateCcw, X } from "lucide-react";
import { toast } from "sonner";
import { architectureApi } from "../../services/api";
import useArchitectureStore from "../../store/useArchitectureStore";

export default function SnapshotMenu({ drawioRef }) {
    const sessionId = useArchitectureStore((s) => s.sessionId);
    const drawioXml = useArchitectureStore((s) => s.drawioXml);
    const applyGeneration = useArchitectureStore((s) => s.applyGeneration);
    const setLoading = useArchitectureStore((s) => s.setLoading);

    const [open, setOpen] = useState(false);
    const [snapshots, setSnapshots] = useState([]);
    const [saving, setSaving] = useState(false);

    const refresh = async () => {
        if (!sessionId) return;
        try {
            const list = await architectureApi.listSnapshots(sessionId);
            setSnapshots(list);
        } catch {}
    };

    useEffect(() => {
        if (open) refresh();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, sessionId]);

    const handleSave = async () => {
        if (!sessionId || !drawioXml) return;
        setSaving(true);
        try {
            // Export latest XML from draw.io iframe
            let xml = drawioXml;
            if (drawioRef?.current?.exportXml) {
                const fresh = await drawioRef.current.exportXml();
                if (fresh) xml = fresh;
            }
            const name = `v${(snapshots?.length || 0) + 1} · ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
            await architectureApi.createSnapshot(sessionId, { name, drawio_xml: xml });
            toast.success("Snapshot saved");
            refresh();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Failed to save snapshot");
        } finally {
            setSaving(false);
        }
    };

    const handleRestore = async (snapId) => {
        if (!sessionId) return;
        setLoading(true, "Restoring snapshot…");
        try {
            const res = await architectureApi.restoreSnapshot(sessionId, snapId);
            applyGeneration(res);
            toast.success("Snapshot restored");
            setOpen(false);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Restore failed");
        } finally {
            setLoading(false);
        }
    };

    if (!sessionId) return null;

    return (
        <div className="relative">
            <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                data-testid="snapshots-btn"
                className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors"
                title="Snapshots / versions"
            >
                <History size={13} />
            </button>
            {open && (
                <>
                    <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
                    <div className="absolute right-0 top-8 z-40 w-72 rounded-lg border border-border bg-card shadow-elevated overflow-hidden fade-up">
                        <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-muted/30">
                            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground font-semibold">
                                Snapshots
                            </span>
                            <button
                                type="button"
                                onClick={() => setOpen(false)}
                                className="p-1 text-muted-foreground hover:text-foreground rounded"
                            >
                                <X size={12} />
                            </button>
                        </div>
                        <button
                            type="button"
                            onClick={handleSave}
                            disabled={saving || !drawioXml}
                            data-testid="snapshot-save-btn"
                            className="w-full flex items-center gap-2 px-3 py-2.5 text-[12px] text-foreground hover:bg-muted disabled:opacity-50 border-b border-border"
                        >
                            <Camera size={13} className="text-primary" />
                            <span>{saving ? "Saving…" : "Save current diagram"}</span>
                        </button>
                        <div className="max-h-72 overflow-y-auto">
                            {snapshots.length === 0 ? (
                                <div className="px-3 py-4 text-[11px] text-muted-foreground">
                                    No snapshots yet
                                </div>
                            ) : (
                                snapshots.map((s) => (
                                    <div
                                        key={s.id}
                                        data-testid={`snapshot-${s.id}`}
                                        className="flex items-center justify-between gap-2 px-3 py-2 border-b border-border last:border-b-0 hover:bg-muted/40"
                                    >
                                        <div className="min-w-0 flex-1">
                                            <div className="text-[12px] text-foreground truncate">{s.name}</div>
                                            <div className="text-[10px] font-mono text-muted-foreground">
                                                #{s.id} · {new Date(s.created_at).toLocaleString()}
                                            </div>
                                        </div>
                                        <button
                                            type="button"
                                            onClick={() => handleRestore(s.id)}
                                            data-testid={`snapshot-restore-${s.id}`}
                                            className="px-2 py-1 text-[10px] uppercase tracking-wider text-primary hover:bg-primary/10 rounded inline-flex items-center gap-1"
                                            title="Restore"
                                        >
                                            <RotateCcw size={11} /> Restore
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}
