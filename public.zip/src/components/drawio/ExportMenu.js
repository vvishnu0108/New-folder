import { useState } from "react";
import { Download, FileImage, FileCode, ChevronDown } from "lucide-react";

/**
 * Triggers draw.io iframe `export` postMessage with the chosen format and
 * downloads the result. `iframeRef` must point to the draw.io iframe.
 */
export default function ExportMenu({ iframeRef, diagramXml }) {
    const [open, setOpen] = useState(false);
    const [busy, setBusy] = useState(false);

    const exportAs = (format) => {
        if (!iframeRef?.current?.contentWindow) return;
        setBusy(true);
        const handler = (event) => {
            if (!event.data || typeof event.data !== "string") return;
            let msg;
            try { msg = JSON.parse(event.data); } catch { return; }
            if (msg.event !== "export") return;
            window.removeEventListener("message", handler);
            setBusy(false);
            setOpen(false);
            const data = msg.data || msg.xml;
            if (!data) return;

            const ext = format === "xmlPng" ? "png" : format;
            const filename = `architecture.${ext}`;
            const a = document.createElement("a");
            if (data.startsWith("data:")) {
                a.href = data;
            } else {
                const mime = format === "svg" ? "image/svg+xml" : "application/xml";
                const blob = new Blob([data], { type: mime });
                a.href = URL.createObjectURL(blob);
            }
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();
        };
        window.addEventListener("message", handler);
        iframeRef.current.contentWindow.postMessage(
            JSON.stringify({ action: "export", format }),
            "*"
        );
        setTimeout(() => {
            window.removeEventListener("message", handler);
            setBusy(false);
        }, 8000);
    };

    const downloadXmlDirect = () => {
        if (!diagramXml) return;
        const blob = new Blob([diagramXml], { type: "application/xml" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "architecture.drawio";
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        setOpen(false);
    };

    return (
        <div className="relative">
            <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                data-testid="export-menu-btn"
                disabled={!diagramXml}
                className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded transition-colors disabled:opacity-40 inline-flex items-center gap-0.5"
                title="Export diagram"
            >
                <Download size={13} />
                <ChevronDown size={10} />
            </button>
            {open && (
                <>
                    <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
                    <div className="absolute right-0 top-8 z-40 w-48 rounded-lg border border-border bg-card shadow-elevated overflow-hidden fade-up">
                        <button
                            type="button"
                            onClick={() => exportAs("png")}
                            disabled={busy}
                            data-testid="export-png-btn"
                            className="w-full flex items-center gap-2 px-3 py-2 text-[12px] text-foreground hover:bg-muted disabled:opacity-50"
                        >
                            <FileImage size={12} className="text-primary" /> Export PNG
                        </button>
                        <button
                            type="button"
                            onClick={() => exportAs("svg")}
                            disabled={busy}
                            data-testid="export-svg-btn"
                            className="w-full flex items-center gap-2 px-3 py-2 text-[12px] text-foreground hover:bg-muted disabled:opacity-50"
                        >
                            <FileImage size={12} className="text-primary" /> Export SVG
                        </button>
                        <button
                            type="button"
                            onClick={downloadXmlDirect}
                            disabled={!diagramXml}
                            data-testid="export-xml-btn"
                            className="w-full flex items-center gap-2 px-3 py-2 text-[12px] text-foreground hover:bg-muted disabled:opacity-50 border-t border-border"
                        >
                            <FileCode size={12} className="text-primary" /> Download .drawio
                        </button>
                    </div>
                </>
            )}
        </div>
    );
}
