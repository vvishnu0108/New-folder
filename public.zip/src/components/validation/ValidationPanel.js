import { ShieldAlert, AlertTriangle, Info } from "lucide-react";

const severityStyles = {
    critical: "border-danger/40 bg-danger/10 text-danger",
    warning: "border-warning/40 bg-warning/10 text-warning",
    info: "border-info/40 bg-info/10 text-info",
};

const severityIcon = (sev) => sev === "critical" ? ShieldAlert : sev === "warning" ? AlertTriangle : Info;

export default function ValidationPanel({ items = [] }) {
    return (
        <div className="space-y-2" data-testid="validation-panel">
            {items.length === 0 && <div className="text-[12px] text-muted-foreground">No validation issues.</div>}
            {items.map((v) => {
                const Icon = severityIcon(v.severity);
                return (
                    <div
                        key={v.id}
                        data-testid={`validation-${v.id}`}
                        className={`rounded-md border px-3 py-2 fade-up ${severityStyles[v.severity] || severityStyles.info}`}
                    >
                        <div className="flex items-start gap-2">
                            <Icon size={13} className="mt-0.5 shrink-0" />
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-2">
                                    <span className="text-[12px] font-medium text-foreground leading-snug">{v.title}</span>
                                    <span className="text-[9px] uppercase tracking-wider font-mono opacity-80">{v.severity}</span>
                                </div>
                                <div className="text-[11px] text-foreground/85 leading-relaxed mt-1">{v.description}</div>
                                {v.recommendation && (
                                    <div className="text-[11px] text-muted-foreground mt-1.5 leading-relaxed">
                                        <span className="uppercase tracking-wider text-[9px] mr-1">fix:</span>
                                        {v.recommendation}
                                    </div>
                                )}
                                {v.impacted_services?.length > 0 && (
                                    <div className="mt-1.5 flex flex-wrap gap-1">
                                        {v.impacted_services.map((s) => (
                                            <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-border bg-card text-foreground">
                                                {s}
                                            </span>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
