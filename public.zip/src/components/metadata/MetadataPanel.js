export default function MetadataPanel({ metadata, score }) {
    if (!metadata) {
        return <div className="text-[12px] text-muted-foreground">Generate an architecture to see metadata.</div>;
    }
    const rows = [
        ["Provider", metadata.cloud_provider],
        ["Type", metadata.architecture_type],
        ["Region strategy", metadata.region_strategy],
        ["HA tier", metadata.ha_tier],
        ["Cost tier", metadata.estimated_cost_tier],
    ].filter(([, v]) => v);

    const scoreColor = score >= 80 ? "text-success" : score >= 60 ? "text-warning" : "text-danger";

    return (
        <div data-testid="metadata-panel" className="space-y-2">
            <div className="rounded-md border border-border bg-card p-3">
                <div className="flex items-center justify-between mb-2">
                    <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
                        Architecture Score
                    </div>
                    <div className={`text-2xl font-semibold tracking-tight font-mono ${scoreColor}`}>
                        {score || 0}
                    </div>
                </div>
                <div className="h-1 w-full bg-muted rounded overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: `${Math.min(100, score || 0)}%` }} />
                </div>
            </div>
            <div className="rounded-md border border-border bg-card divide-y divide-border">
                {rows.map(([k, v]) => (
                    <div key={k} className="px-3 py-1.5 flex items-center justify-between">
                        <span className="text-[11px] text-muted-foreground">{k}</span>
                        <span className="text-[12px] text-foreground font-mono">{v}</span>
                    </div>
                ))}
            </div>
            {metadata.services?.length > 0 && (
                <div className="rounded-md border border-border bg-card p-3">
                    <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mb-2">
                        Services ({metadata.services.length})
                    </div>
                    <div className="flex flex-wrap gap-1">
                        {metadata.services.map((s) => (
                            <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-border bg-muted/40 text-foreground">
                                {s}
                            </span>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
