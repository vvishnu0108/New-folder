import { useState } from "react";
import { useTheme } from "../contexts/ThemeContext";
import { Sun, Moon, PanelLeftClose, PanelRightClose, PanelLeftOpen, PanelRightOpen, Maximize2, Minimize2 } from "lucide-react";
import LeftSidebar from "../components/sidebar/LeftSidebar";
import RightSidebar from "../components/sidebar/RightSidebar";
import CenterWorkspace from "../components/workspace/CenterWorkspace";
import useArchitectureStore from "../store/useArchitectureStore";

export default function Workspace() {
    const { theme, toggleTheme } = useTheme();
    const [leftOpen, setLeftOpen] = useState(true);
    const [rightOpen, setRightOpen] = useState(true);
    const [canvasFullscreen, setCanvasFullscreen] = useState(false);
    const reset = useArchitectureStore((s) => s.reset);
    const drawioXml = useArchitectureStore((s) => s.drawioXml);

    return (
        <div
            className="flex flex-col h-screen w-screen bg-background text-foreground overflow-hidden"
            data-testid="workspace-root"
        >
            {/* Top bar */}
            <header
                className="h-14 shrink-0 flex items-center justify-between px-4 border-b border-border bg-card/70 backdrop-blur z-20"
                data-testid="app-header"
            >
                <div className="flex items-center gap-3">
                    <button
                        type="button"
                        onClick={() => setLeftOpen((v) => !v)}
                        data-testid="toggle-left-sidebar"
                        className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors focus-ring"
                        title={leftOpen ? "Hide left panel" : "Show left panel"}
                    >
                        {leftOpen ? <PanelLeftClose size={16} /> : <PanelLeftOpen size={16} />}
                    </button>
                    <button
                        type="button"
                        onClick={reset}
                        data-testid="brand-button"
                        className="flex items-center gap-2.5 group focus-ring rounded px-1.5 py-1 -ml-1"
                    >
                        <div className="h-7 w-7 rounded-md bg-primary flex items-center justify-center shadow-sm">
                            <span className="font-bold text-primary-foreground text-[13px] tracking-tight">
                                A
                            </span>
                        </div>
                        <div className="leading-tight text-left">
                            <div className="text-[14px] font-semibold tracking-tight text-foreground group-hover:text-primary transition-colors">
                                Architect Studio
                            </div>
                        </div>
                    </button>
                </div>

                <div className="flex items-center gap-1.5">
                    {drawioXml && (
                        <button
                            type="button"
                            onClick={() => setCanvasFullscreen((v) => !v)}
                            data-testid="toggle-canvas-fullscreen"
                            className="px-2.5 py-1.5 text-[11px] uppercase tracking-wider text-muted-foreground hover:text-foreground border border-border hover:border-border-strong rounded-md transition-all flex items-center gap-1.5 focus-ring"
                            title={canvasFullscreen ? "Exit distraction-free" : "Distraction-free canvas"}
                        >
                            {canvasFullscreen ? <Minimize2 size={12} /> : <Maximize2 size={12} />}
                            <span className="hidden md:inline">{canvasFullscreen ? "Exit" : "Focus"}</span>
                        </button>
                    )}
                    <button
                        type="button"
                        onClick={toggleTheme}
                        data-testid="theme-toggle"
                        className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors focus-ring"
                        title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
                    >
                        {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
                    </button>
                    <button
                        type="button"
                        onClick={() => setRightOpen((v) => !v)}
                        data-testid="toggle-right-sidebar"
                        className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors focus-ring"
                        title={rightOpen ? "Hide right panel" : "Show right panel"}
                    >
                        {rightOpen ? <PanelRightClose size={16} /> : <PanelRightOpen size={16} />}
                    </button>
                </div>
            </header>

            <div className="flex flex-1 overflow-hidden">
                <div
                    className="sidebar-collapse"
                    style={{
                        width: leftOpen && !canvasFullscreen ? "18rem" : "0rem",
                        minWidth: leftOpen && !canvasFullscreen ? "18rem" : "0rem",
                        opacity: leftOpen && !canvasFullscreen ? 1 : 0,
                    }}
                    aria-hidden={!leftOpen || canvasFullscreen}
                >
                    <LeftSidebar />
                </div>

                <CenterWorkspace canvasFullscreen={canvasFullscreen} />

                <div
                    className="sidebar-collapse"
                    style={{
                        width: rightOpen && !canvasFullscreen ? "22rem" : "0rem",
                        minWidth: rightOpen && !canvasFullscreen ? "22rem" : "0rem",
                        opacity: rightOpen && !canvasFullscreen ? 1 : 0,
                    }}
                    aria-hidden={!rightOpen || canvasFullscreen}
                >
                    <RightSidebar />
                </div>
            </div>
        </div>
    );
}
