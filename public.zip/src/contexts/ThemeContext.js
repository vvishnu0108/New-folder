import { createContext, useContext, useEffect, useState, useCallback } from "react";

const ThemeContext = createContext({
    theme: "light",
    setTheme: () => {},
    toggleTheme: () => {},
});

export function ThemeProvider({ children }) {
    const [theme, setThemeState] = useState(() => {
        if (typeof window === "undefined") return "light";
        const saved = localStorage.getItem("architect-studio-theme");
        if (saved === "light" || saved === "dark") return saved;
        const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        return prefersDark ? "dark" : "light";
    });

    useEffect(() => {
        const root = document.documentElement;
        if (theme === "dark") {
            root.classList.add("dark");
        } else {
            root.classList.remove("dark");
        }
        localStorage.setItem("architect-studio-theme", theme);
    }, [theme]);

    const setTheme = useCallback((value) => {
        setThemeState(value === "dark" ? "dark" : "light");
    }, []);

    const toggleTheme = useCallback(() => {
        setThemeState((t) => (t === "dark" ? "light" : "dark"));
    }, []);

    return (
        <ThemeContext.Provider value={{ theme, setTheme, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
}

export function useTheme() {
    return useContext(ThemeContext);
}
